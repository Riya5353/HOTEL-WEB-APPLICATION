package BEAN;

import java.io.Serializable;

public class UserBean implements Serializable
{
private  Long aadharno;
private String username;
private Long mobileno;
private String address;
private String mailid;

public UserBean(Long aadharno, String username, Long mobileno, String address, String mailid) 
{
	super();
	this.aadharno = aadharno;
	this.username = username;
	this.mobileno = mobileno;
	this.address = address;
	this.mailid = mailid;
}

public UserBean() {
	super();
}

public Long getAadharno() {
	return aadharno;
}

public void setAadharno(Long aadharno) {
	this.aadharno = aadharno;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public Long getMobileno() {
	return mobileno;
}

public void setMobileno(Long mobileno) {
	this.mobileno = mobileno;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getMailid() {
	return mailid;
}

public void setMailid(String mailid) {
	this.mailid = mailid;
}



}
