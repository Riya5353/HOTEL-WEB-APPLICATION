package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import BEAN.UserBean;
import DB.DBConnection;

public class LoginDAO 
{
	public UserBean login(Long aadharno ,String uname)
	{
		UserBean ub = null;
		try
		{
			Connection con = DBConnection.getcon();
			PreparedStatement ps = con.prepareStatement("select * from register  where AADHAR_NO = ? and USERNAME = ?");
			ps.setLong(1, aadharno); 
			ps.setString(2, uname); 
			ResultSet rs = ps.executeQuery();
			
			if (rs.next())
			{
				ub=new UserBean();
				ub.setAadharno(rs.getLong(1));
				ub.setUsername(rs.getString(2));
				ub.setMobileno(rs.getLong(3));
				ub.setAddress(rs.getString(4));
				ub.setMailid(rs.getString(5));
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return ub;
	}
}
