package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;

import BEAN.UserBean;
import DB.DBConnection;


public class RegistrationDAO 
{
	int k = 0;
	public int register(UserBean ub)
	{
		try 
		{
			Connection con = DBConnection.getcon();
			PreparedStatement ps = con.prepareStatement("insert into register values(?,?,?,?,?)");
			ps.setLong(1, ub.getAadharno());
			ps.setString(2, ub.getUsername());
			ps.setLong(3, ub.getMobileno());
			ps.setString(4, ub.getAddress());
			ps.setString(5, ub.getMailid());
			k=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return k;
}
}
		
