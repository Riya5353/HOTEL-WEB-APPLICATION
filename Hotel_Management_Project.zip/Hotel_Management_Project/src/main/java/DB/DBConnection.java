package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.logging.Logger;

public class DBConnection 
{
	//private static final Logger LOGGER=Logger.getLogger(DBConnection.class.getName());
private static Connection con;

private void DBconnection()
{
	
}
static
{
	try 
	{
		Class.forName(DBinfo.driver);
		con=DriverManager.getConnection(DBinfo.dbUrl,DBinfo.uName,DBinfo.pword);
		//LOGGER.info("Connection object is created"+con);
	}
	catch (Exception e)
	{
		//LOGGER.warning("EXCEPTION WHILE CONNECTIONG TO DATABASE");
		e.printStackTrace();
	}
}
public static Connection getcon()
{
	return con;
}
//public static void main(String[] args) 
//{
//	Connection con2=getcon();
//	System.out.println(con2);
//}
}
