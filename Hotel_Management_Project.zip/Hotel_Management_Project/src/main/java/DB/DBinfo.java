package DB;

public interface DBinfo 
{
public static final String 
driver="oracle.jdbc.driver.OracleDriver";
public static final String
dbUrl="jdbc:oracle:thin:@localhost:1522:xe";
public static final String uName="system";
public static final String pword="manager";

}
