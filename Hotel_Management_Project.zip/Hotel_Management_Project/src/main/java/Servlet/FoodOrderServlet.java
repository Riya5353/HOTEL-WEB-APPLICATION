package Servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;

@WebServlet("/food")
public class FoodOrderServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Get selected items from the request parameters
		String[] vegetarianItems = request.getParameterValues("vegetarian_items");
		String[] vegetarianItemsPrice = request.getParameterValues("vegetarian_items_price");
		String[] nonVegetarianItems = request.getParameterValues("non_vegetarian_items");
		String[] nonVegetarianItemsPrice = request.getParameterValues("non_vegetarian_items_price");
		System.out.println(Arrays.toString(vegetarianItems));
		System.out.println(Arrays.toString(nonVegetarianItems));
		// Process and print selected items
		response.setContentType("text/html");
		response.getWriter().println("<html><body>");
		
	

		response.getWriter().println("<h2>Selected Vegetarian Items:</h2>");
		Double vegbill = 0.0;
		if (vegetarianItems != null) {
			for (String item : vegetarianItems) {
				response.getWriter().println("<p>" + item + "</p>");
			}
			for (String item : vegetarianItemsPrice) {
				vegbill+= Double.parseDouble(item);
			}

			
		} else {
			response.getWriter().println("<p>No vegetarian items selected.</p>");
		}
		Double nonVegBill = 0.0;
		response.getWriter().println("<h2>Selected Non-Vegetarian Items:</h2>");
		if (nonVegetarianItems != null && nonVegetarianItemsPrice!=null) {
			for (String item : nonVegetarianItems) {
				response.getWriter().println("<p>" + item + "</p>");
			}
			for (String item : nonVegetarianItemsPrice) {
				nonVegBill+=Double.parseDouble(item);
			}
			
		} else {
			response.getWriter().println("<p>No non-vegetarian items selected.</p>");
		}
		Double totBill = vegbill+nonVegBill;
		response.getWriter().println("<h1>Total Bill : "+totBill+"</h1>");
		response.getWriter().println("</body></html>");
	}
}
