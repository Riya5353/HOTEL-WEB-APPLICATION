package Servlet;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;

import BEAN.UserBean;
import DAO.LoginDAO;
@SuppressWarnings("serial")
@WebServlet("/login")

public class LoginServlet extends GenericServlet
{
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException 
	{
		
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");
		Long aadharno=Long.parseLong(req.getParameter("adhar_no"));
		String uname=req.getParameter("uname");
		UserBean ub=new LoginDAO().login(aadharno , uname);
		
		if (ub==null)
		{
			pw.println("<h3>User Not Available, Kindly Register</h3>");
			req.getRequestDispatcher("Registration.html").include(req, res);
		}
		else
		{
			pw.println("Hello USer  : "+ub.getUsername());
			pw.println("now you can go for search .... our amazing hotel .....choose your best and  comfotable one ");
			req.getRequestDispatcher("Category.html").include(req, res);
		}
		}
		
	}


