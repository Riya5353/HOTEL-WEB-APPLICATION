package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

import BEAN.UserBean;
import DAO.RegistrationDAO;

@SuppressWarnings("serial")
@WebServlet("/reg")

public class RegisterServlet extends GenericServlet
{

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException 
	{
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");
		UserBean ub = new UserBean();
		ub.setAadharno(Long.parseLong(req.getParameter("adhar_no")));
		ub.setUsername(req.getParameter("user"));
		ub.setMobileno(Long.parseLong(req.getParameter("mno")));
		ub.setAddress(req.getParameter("addr"));
		ub.setMailid(req.getParameter("mid"));
		int k = new RegistrationDAO().register(ub);
		
		if(k>0)
		{
			pw.println("<h3>Register Successfull</h3>");
			req.getRequestDispatcher("index.html").include(req, res);
		}
		else
		{
			pw.println("Something Went Wrong");
			req.getRequestDispatcher("index.html").include(req, res);
		}
		
		
	}

}
