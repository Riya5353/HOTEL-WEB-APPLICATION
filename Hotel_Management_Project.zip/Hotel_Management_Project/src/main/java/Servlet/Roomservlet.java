package Servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;

@WebServlet("/room")
public class Roomservlet extends HttpServlet 
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		String[] singleroom  = request.getParameterValues("single_room");
		String [] singleroomprice=request.getParameterValues("single_room_price");
		
		String[] doubleeroom  = request.getParameterValues("double_room");
		String [] doubleroomprice=request.getParameterValues("double_room_price");
		
		response.setContentType("text/html");
		response.getWriter().println("<html><body>");
		
		response.getWriter().println("<h2>Selecte single room:</h2>");
		Double singlebill = 0.0;
		
		if (singleroom != null) {
			for (String item :singleroom) {
				response.getWriter().println("<p>" + item + "</p>");
			}
			for (String item : singleroomprice) {
				singlebill+= Double.parseDouble(item);
			}
		} else {
			response.getWriter().println("<p> no single room selected </p>");
		}
		
		response.getWriter().println("<h2>Selectet double room:</h2>");
		Double doublebill = 0.0;
		
		if (doubleeroom != null) {
			for (String item :doubleeroom) {
				response.getWriter().println("<p>" + item + "</p>");
			}
			for (String item : doubleroomprice) {
				doublebill+= Double.parseDouble(item);
			}
		} else {
			response.getWriter().println("<p> no double room selected </p>");
		}
		Double totBill = singlebill+doublebill;
		response.getWriter().println("<h1>Total Bill : "+totBill+"</h1>");
		response.getWriter().println("</body></html>");
	
	}
	

}
